 <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
<header  id="header"  >
  
  <div class="container"> 

<nav  class="navbar    navbar-expand-lg navbar-dark "> 
<a class="navbar-brand"  href="<?php echo BASE_URL; ?>"><img src="assets/images/logo.png"   ></a>
 

<button class="navbar-toggler   nav_button" type="button" data-toggle="collapse" data-target="#nav_button" aria-controls="nav_button" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>


<div class="collapse navbar-collapse  " id="nav_button">
 
	<ul id="menu-nav" class="navbar-nav ml-auto"> 
          <li><a href="#overview" class="nav-link  href_toscroll">Overview</a></li>
          <li><a href="#course" class="nav-link href_toscroll">Courses </a></li> 
          <li><a href="#instructor" class="nav-link href_toscroll">Instructor</a></li>           <li><a href="#infosectrain" class="nav-link href_toscroll">Why Infosectrain</a></li>         
          <li><a href="#reviews" class="nav-link href_toscroll">Review  </a></li>          
        
         	
</ul></div> 
  
 
</nav> </div></header>